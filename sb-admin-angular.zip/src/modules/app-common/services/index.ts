import { AppCommonService } from './app-common.service';

export const services = [AppCommonService];

export * from './app-common.service';
